library(dplyr)
library(plotly)
library(RColorBrewer)
library(scales)
library(Seurat)

# ---- 读取 Seurat 对象 ----
setwd("C:/Users/bioin/Downloads/Marine_revision/Marine_new_matrix/Matrix")
combined_seurat_object <- readRDS("marine_SeuratObject_dim20_res10_manual.rds")

combined_seurat_object$site <- recode(
  combined_seurat_object$site,
  "ZJ" = "L1",
  "SG" = "L2",
  "HY" = "L3",
  "ZS" = "L4"
)

meta <- combined_seurat_object@meta.data

#--------------------------------------------------
# Site顺序
#--------------------------------------------------
meta$site <- factor(
  meta$site,
  levels = c("L1", "L2", "L3", "L4")
)

#--------------------------------------------------
# Cluster
#--------------------------------------------------
meta$cluster <- as.character(meta$manual_cluster)

#--------------------------------------------------
# Top15 genus
#--------------------------------------------------
top15 <- meta %>%
  count(genus, sort = TRUE) %>%
  slice_head(n = 15) %>%
  pull(genus)

#--------------------------------------------------
# Top15 genus
#--------------------------------------------------
top15 <- meta %>%
  count(genus, sort = TRUE) %>%
  slice_head(n = 15) %>%
  pull(genus)

meta <- meta %>%
  mutate(
    genus_plot = ifelse(
      genus %in% top15,
      paste0("<i>", genus, "</i>"),
      "Others"
    ),
    cluster = as.character(manual_cluster)
  )

#--------------------------------------------------
# 节点顺序
#--------------------------------------------------
site_levels <- c(
  "L1", "L2", "L3", "L4"
)

cluster_levels <- as.character(
  sort(as.numeric(unique(meta$cluster)))
)

genus_levels <- meta %>%
  count(genus_plot, sort = TRUE) %>%
  pull(genus_plot)

# Others放最后
genus_levels <- genus_levels[
  genus_levels != "Others"
]

genus_levels <- c(
  genus_levels,
  "Others"
)

#--------------------------------------------------
# Nodes
#--------------------------------------------------
nodes <- c(
  site_levels,
  cluster_levels,
  genus_levels
)

node_id <- setNames(
  seq_along(nodes) - 1,
  nodes
)

#--------------------------------------------------
# Links
#--------------------------------------------------
link1 <- meta %>%
  count(site, cluster)

link2 <- meta %>%
  count(cluster, genus_plot)

source <- c(
  node_id[as.character(link1$site)],
  node_id[link2$cluster]
)

target <- c(
  node_id[link1$cluster],
  node_id[link2$genus_plot]
)

value <- c(
  link1$n,
  link2$n
)

#--------------------------------------------------
# 颜色
#--------------------------------------------------
cluster_colors <- c(
  "0"="#9ECAE1",
  "1"="#D2B48C",
  "2"="#7570b3",
  "3"="#D3D3D3",
  "4"="#D0DDCC",
  "5"="#FFE4E1",
  "6"="#4192C6",
  "7"="#FFFF99",
  "8"="#e6ab02",
  "9"="#D8BFD8",
  "10"="#fb9a99",
  "11"="#b2df8a",
  "12"="#B07AA1",
  "13"="#A9A9A9",
  "14"="#59A14F"
)

cluster_colors <- cluster_colors[cluster_levels]

site_palette <- c(
  "L1" = "#66C2A5",
  "L2" = "#FC8D62",
  "L3" = "#8DA0CB",
  "L4" = "#E78AC3"
)

genus_palette <- setNames(
  colorRampPalette(
    brewer.pal(12, "Paired")
  )(length(genus_levels)),
  genus_levels
)

genus_palette["Others"] <- "#D0D0D0"

node_color <- c(
  site_palette[site_levels],
  cluster_colors[cluster_levels],
  genus_palette[genus_levels]
)

# link颜色继承cluster颜色
link_color <- alpha(
  c(
    cluster_colors[link1$cluster],
    cluster_colors[link2$cluster]
  ),
  0.5
)

#--------------------------------------------------
# 节点位置
#--------------------------------------------------
n_site <- length(site_levels)
n_cluster <- length(cluster_levels)
n_genus <- length(genus_levels)

# x坐标
x_pos <- c(
  rep(0.01, n_site),
  rep(0.50, n_cluster),
  rep(0.99, n_genus)
)

# y坐标
y_pos <- numeric(length(nodes))

# Site
y_pos[1:n_site] <- c(
  0.30,   # L1
  0.45,   # L2
  0.60,   # L3
  0.75    # L4
)

# Cluster
cluster_start <- n_site + 1
cluster_end <- cluster_start + n_cluster - 1

y_pos[cluster_start:cluster_end] <- c(
  seq(0.05, 0.25, length.out = 3),   # 0–3 紧
  seq(0.35, 0.60, length.out = 4),   # 4–5
  seq(0.65, 0.95, length.out = 6)    # 6–12 松
)

# Genus（按丰度降序）
genus_start <- cluster_end + 1
genus_end <- length(nodes)

# genus y position
y_pos[genus_start:genus_end] <- seq(
  0.05,
  0.90,
  length.out = n_genus
)

# Others单独拉到底部
others_idx <- which(genus_levels == "Others")
y_pos[genus_start + others_idx - 1] <- 0.95

#--------------------------------------------------
# Sankey
#--------------------------------------------------
fig <- plot_ly(
  type = "sankey",
  arrangement = "free",
  
  node = list(
    label = nodes,
    color = node_color,
    pad = 15,
    thickness = 8,
    line = list(width = 0),
    x = x_pos,
    y = y_pos
  ),
  
  link = list(
    source = source,
    target = target,
    value = value,
    color = link_color
  )
)

fig <- fig %>%
  layout(
    title = "Site → Cluster → Genus",
    font = list(size = 10)
  )

fig