# =========================================
# 四层 Circos + base R 图例（右侧）
# =========================================

library(dplyr)
library(circlize)
library(RColorBrewer)

# ---- 1. 准备数据 ----
setwd("C:/Users/bioin/Downloads/Marine_revision/Marine_new_matrix/Matrix")
combined_seurat_object <- readRDS("marine_SeuratObject_dim20_res10_manual.rds")
meta <- combined_seurat_object@meta.data %>%
  filter(!is.na(genus) & !is.na(species) &
           !is.na(manual_cluster) & !is.na(site)) %>%
  mutate(
    Cluster = as.factor(manual_cluster),
    Site = as.factor(site),
    Genus = as.factor(genus),
    Species = as.factor(species)
  )

# ---- 2. 计算每层细胞数 ----
df <- meta %>%
  group_by(Cluster, Site, Genus, Species) %>%
  summarise(value = n(), .groups = "drop")

# ---- 3. Top15 Genus / Top20 Species，其他标为 Others ----
top_genus <- df %>% group_by(Genus) %>% summarise(total=sum(value)) %>% arrange(desc(total)) %>% slice_head(n=15) %>% pull(Genus)
df <- df %>% mutate(Genus_plot = ifelse(Genus %in% top_genus, as.character(Genus), "Others"))

top_species <- df %>% group_by(Species) %>% summarise(total=sum(value)) %>% arrange(desc(total)) %>% slice_head(n=20) %>% pull(Species)
df <- df %>% mutate(Species_plot = ifelse(Species %in% top_species, as.character(Species), "Others"))

# ---- 4. 设置颜色 ----
cluster_palette <- c(
  "0"="#9ECAE1",
  "1"="#D2B48C",
  "2"="#7570b3",
  "3"="#D3D3D3",
  "4"="#D0DDCC",
  "5"="#FFE4E1",
  "6"="#4192C6",
  "7"="#FFFF99",
  "8"="#e6ab02",
  "9"="#D8BFD8",
  "10"="#fb9a99",
  "11"="#b2df8a",
  "12"="#B07AA1",
  "13"="#A9A9A9",
  "14"="#59A14F"
)
#names(cluster_palette) <- unique(df$Cluster)

site_palette <- RColorBrewer::brewer.pal(n = length(unique(df$Site)), "Set2")
names(site_palette) <- unique(df$Site)

genus_palette <- colorRampPalette(brewer.pal(12,"Paired"))(length(unique(df$Genus_plot)))
names(genus_palette) <- unique(df$Genus_plot)
genus_palette["Others"] <- "grey80"

species_palette <- colorRampPalette(brewer.pal(12,"Set3"))(length(unique(df$Species_plot)))
names(species_palette) <- unique(df$Species_plot)
species_palette["Others"] <- "grey90"

# ---- 5. 计算 cluster 总细胞数并加最小宽度保护 ----
cluster_cellcounts <- df %>% group_by(Cluster) %>% summarise(value=sum(value))
cluster_cellcounts$value <- pmax(cluster_cellcounts$value, 1) # 宽度 ≥1

# ---- 6. 绘制 Circos ----
pdf("Fig4b-cluster_site_genus_species_circos.pdf", width=14, height=12)

par(mar = c(2,2,2,18))  # 右侧留空间放legend

circos.clear()
circos.par(start.degree = 90, gap.degree = 1,
           track.margin=c(0.005,0.005),
           cell.padding=c(0,0,0,0))

# 外圈 Cluster（更细 + 去边框）
circos.initialize(factors = cluster_cellcounts$Cluster,
                  xlim = cbind(rep(0, nrow(cluster_cellcounts)),
                               as.numeric(cluster_cellcounts$value)))

circos.trackPlotRegion(
  factors = cluster_cellcounts$Cluster,
  y = rep(1, nrow(cluster_cellcounts)),
  ylim = c(0,1),
  track.height = 0.02,   # ✅ 更细
  bg.col = cluster_palette[as.character(cluster_cellcounts$Cluster)],
  bg.border = NA,        # ✅ 去边框
  panel.fun = function(x,y){
    if(length(x)==0 || all(is.na(x))) return()
    sector.index <- get.cell.meta.data("sector.index")
    circos.text(mean(as.numeric(x)), 0.5, sector.index,
                facing="bending.outside", cex=0.7)
  })

# 第二圈 Site（更细）
circos.track(ylim=c(0,1), track.height=0.02, bg.border=NA)
for(cl in cluster_cellcounts$Cluster){
  sub_df <- df %>% filter(Cluster==cl) %>%
    group_by(Site) %>% summarise(value=sum(value), .groups="drop")
  
  sub_df$value <- pmax(sub_df$value, 1)
  
  x_start <- 0
  for(i in 1:nrow(sub_df)){
    x_end <- x_start + sub_df$value[i]
    circos.rect(x_start,0,x_end,1,
                sector.index=cl,
                col=site_palette[sub_df$Site[i]],
                border=NA,
                track.index=2)
    x_start <- x_end
  }
}

# 第三圈 Genus（更细）
circos.track(ylim=c(0,1), track.height=0.02, bg.border=NA)
for(cl in cluster_cellcounts$Cluster){
  sub_df <- df %>% filter(Cluster==cl) %>%
    group_by(Site, Genus_plot) %>%
    summarise(value=sum(value), .groups="drop")
  
  sub_df$value <- pmax(sub_df$value, 1)
  
  x_start <- 0
  for(i in 1:nrow(sub_df)){
    x_end <- x_start + sub_df$value[i]
    circos.rect(x_start,0,x_end,1,
                sector.index=cl,
                col=genus_palette[sub_df$Genus_plot[i]],
                border=NA,
                track.index=3)
    x_start <- x_end
  }
}

# 第四圈 Species（更细）
circos.track(ylim=c(0,1), track.height=0.02, bg.border=NA)
for(cl in cluster_cellcounts$Cluster){
  sub_df <- df %>% filter(Cluster==cl) %>%
    group_by(Site, Genus_plot, Species_plot) %>%
    summarise(value=sum(value), .groups="drop")
  
  sub_df$value <- pmax(sub_df$value, 1)
  
  x_start <- 0
  for(i in 1:nrow(sub_df)){
    x_end <- x_start + sub_df$value[i]
    circos.rect(x_start,0,x_end,1,
                sector.index=cl,
                col=species_palette[sub_df$Species_plot[i]],
                border=NA,
                track.index=4)
    x_start <- x_end
  }
}

# ---- 7. 右侧图例（无边框 + 垂直排列）----
par(xpd=NA)

legend(x=1.15, y=1,
       legend=names(cluster_palette),
       fill=cluster_palette,
       border=NA, title="Cluster", ncol=4, cex=0.8)

legend(x=1.15, y=0.75,
       legend=names(site_palette),
       fill=site_palette,
       border=NA, title="Site", ncol=4, cex=0.8)

legend(x=1.15, y=0.5,
       legend=names(genus_palette),
       fill=genus_palette,
       border=NA, title="Genus", ncol=4, cex=0.8)

legend(x=1.15, y=0.25,
       legend=names(species_palette),
       fill=species_palette,
       border=NA, title="Species", ncol=3, cex=0.7)

dev.off()
