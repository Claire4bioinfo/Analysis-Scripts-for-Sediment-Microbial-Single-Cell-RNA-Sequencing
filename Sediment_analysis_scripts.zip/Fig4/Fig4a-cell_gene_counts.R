library(ggplot2)
library(dplyr)
library(gridExtra)

# ---- 读取meta数据 ----
setwd("C:/Users/bioin/Downloads/Marine_revision/Marine_new_matrix/Matrix")
combined_seurat_object <- readRDS("marine_SeuratObject_dim20_res10_manual.rds")
meta <- combined_seurat_object@meta.data

# ---- 定义 sample 顺序和颜色 ----
sample_order <- c("ZJB", "ZJ5", "SGB", "SG5", "HYB", "HY5", "ZSB", "ZS4")
sample_palette <- c(
  "ZJB" = "#BBDED6",
  "ZJ5" = "#D8BFD8",
  "SGB" = "#FFDAB9",
  "SG5" = "#FFA07A",
  "HYB" = "#87CEFA",
  "HY5" = "#9370DB",
  "ZSB" = "#90EE90",
  "ZS4" = "#F4A460"
)

# ---- 计算每个样本的细胞数 ----
cell_counts <- meta %>%
  group_by(sample) %>%
  summarise(cell_count = n()) %>%
  ungroup() %>%
  mutate(sample = factor(sample, levels = sample_order)) %>%
  arrange(sample)

# ---- 上 panel: barplot ----
p_bar <- ggplot(cell_counts, aes(x = sample, y = cell_count, fill = sample)) +
  geom_bar(stat = "identity", width = 0.55, color = "black", size = 0.8) +
  scale_fill_manual(values = sample_palette) +
  labs(y = "Cell Counts", x = "") +
  theme_bw() +
  theme(
    axis.text.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.text.y = element_text(size = 15),
    axis.title.y = element_text(size = 20),
    panel.border = element_rect(size = 1)
  ) +
  scale_y_continuous(breaks = seq(0, max(cell_counts$cell_count) + 5000, 5000))

# ---- 下 panel: violin + boxplot for gene counts per cell ----
p_violin <- ggplot(meta, aes(x = factor(sample, levels = sample_order), y = gene_number, fill = sample)) +
  geom_violin(trim = TRUE, color = NA, alpha = 0.8, width = 0.8) +
  geom_boxplot(width = 0.22, fill = "white", outlier.shape = NA,
               color = "black", size = 1.2, median.size = 1.8) +
  scale_fill_manual(values = sample_palette) +
  labs(y = "Gene Counts per Cell", x = "Samples") +
  theme_bw() +
  theme(
    axis.text.x = element_text(size = 15, angle = 45, hjust = 1),
    axis.text.y = element_text(size = 15),
    axis.title = element_text(size = 20),
    panel.border = element_rect(size = 1)
  ) +
  scale_y_continuous(breaks = seq(0, 200, 30), limits = c(-10, 200))

# ---- 输出 PDF 矢量图 ----
pdf("Figure3a-gene_count.pdf", width = 7, height = 9)
grid.arrange(p_bar, p_violin, heights = c(1, 1.2))
dev.off()
