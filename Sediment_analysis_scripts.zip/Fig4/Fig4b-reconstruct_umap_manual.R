library(Seurat)
library(dplyr)
library(ggplot2)
library(harmony)
library(tidyverse)
library(tidyr)
library(ggrepel)
library(glmGamPoi)
library(RColorBrewer)
library(ggsci)
library(viridis)
library(Matrix)
library(pracma)
library(randomcoloR)
library(scico)

setwd("C:/Users/bioin/Downloads/Marine_revision/Marine_new_matrix/Matrix")
data_path <- "C:/Users/bioin/Downloads/Marine_revision/Marine_new_matrix/Matrix"

###manually merge cluster
combined_seurat_object <- readRDS("marine_SeuratObject_dim20_res10.rds")
# 查看当前 cluster
table(combined_seurat_object$seurat_clusters)

# 先复制一个新的 metadata 列，用于手动合并
combined_seurat_object$manual_cluster <- combined_seurat_object$seurat_clusters

# 根据umap和markers，定义手动合并的映射
merge_map <- list(
  "0_17" = c(0, 17),
  "1_18" = c(1, 18),
  "4_7" = c(4, 7),
  "6_19" = c(6, 19),
  "8_15" = c(8, 15)
)

# 先把 manual_cluster 转为字符
combined_seurat_object$manual_cluster <- as.character(combined_seurat_object$manual_cluster)

# 遍历映射合并 cluster
for (new_cluster in names(merge_map)) {
  combined_seurat_object$manual_cluster[
    combined_seurat_object$manual_cluster %in% merge_map[[new_cluster]]
  ] <- new_cluster
}

# 再转回 factor
combined_seurat_object$manual_cluster <- as.factor(combined_seurat_object$manual_cluster)

# 检查结果
table(combined_seurat_object$manual_cluster)
# 画 UMAP
DimPlot(combined_seurat_object, group.by = "manual_cluster", label = TRUE)


# 统计每个 manual_cluster 的细胞数，并按降序排序
cluster_counts <- sort(table(combined_seurat_object$manual_cluster), decreasing = TRUE)

# 为每个 cluster 分配新编号 0,1,2,...
new_ids <- setNames(as.character(0:(length(cluster_counts)-1)), names(cluster_counts))

# 映射旧 cluster -> 新编号
combined_seurat_object$manual_cluster <- unname(new_ids[as.character(combined_seurat_object$manual_cluster)])

# 转回 factor（可选，画图用）
combined_seurat_object$manual_cluster <- factor(combined_seurat_object$manual_cluster, 
                                                levels = 0:(length(cluster_counts)-1))

# 检查新编号
table(combined_seurat_object$manual_cluster)

# 1️⃣ 确认 cluster 数量
length(levels(combined_seurat_object$manual_cluster))  # 应该是 15

# 2️⃣ 选取 15 种颜色
cluster_colors <- c("#9ECAE1","#D2B48C","#7570b3","#D3D3D3","#D0DDCC",
                    "#FFE4E1","#4192C6","#FFFF99","#e6ab02","#D8BFD8",
                    "#fb9a99","#b2df8a","#B07AA1","#A9A9A9","#59A14F")

# 3️⃣ 绘制 UMAP，指定颜色
p_cluster <- DimPlot(combined_seurat_object, 
                     group.by = "manual_cluster", 
                     label = TRUE, cols = cluster_colors) +
                     ggtitle("UMAP of 15 manual clusters")

ggsave(file.path(data_path,"Fig4b-UMAP_by_manual_cluster.pdf"), p_cluster, width=7, height=6, dpi=300)
saveRDS(combined_seurat_object, file.path(data_path,"marine_SeuratObject_dim20_res10_manual.rds"))





###Find markers for manual clusters
# 确认 manual_cluster 是 factor
combined_seurat_object$manual_cluster <- factor(combined_seurat_object$manual_cluster)

combined_seurat_object <- PrepSCTFindMarkers(combined_seurat_object)
# 找 marker 基因
# logfc.threshold = 0.25 是默认值，可根据需要调整
# min.pct = 0.1 表示至少 10% 的细胞表达
markers <- FindAllMarkers(
  combined_seurat_object,
  assay = "SCT",                   # 也可以用 "SCT" 如果你做了 SCTransform
  group.by = "manual_cluster",
  only.pos = TRUE,                 # 只找上调 marker
  min.pct = 0.02,
  logfc.threshold = 0.1
)

# 查看前几个 marker
head(markers)

# 保存到 CSV
write.table(markers, file = "manual_cluster_markers.tsv", sep = "\t",quote = FALSE, row.names = FALSE)

