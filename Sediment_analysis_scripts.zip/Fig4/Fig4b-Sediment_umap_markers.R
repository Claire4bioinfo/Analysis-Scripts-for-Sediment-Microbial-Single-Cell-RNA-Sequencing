library(Seurat)
library(dplyr)
library(ggplot2)
library(harmony)
library(tidyverse)
library(tidyr)
library(ggrepel)
library(glmGamPoi)
library(RColorBrewer)
library(ggsci)
library(viridis)
library(Matrix)
library(pracma)
library(randomcoloR)
library(scico)

setwd("C:/Users/bioin/Downloads/Marine_revision/Marine_new_matrix/Matrix")
data_path <- "C:/Users/bioin/Downloads/Marine_revision/Marine_new_matrix/Matrix"

sample_dirs <- list.dirs(data_path, full.names = FALSE, recursive = FALSE)
seurat_list <- list()

for (sample_name in sample_dirs) {

  taxonomy_file <- file.path(data_path, paste0(sample_name, "_sc_taxonomy.report"))
  taxonomy_G_file <- file.path(data_path, paste0(sample_name, "_sc_taxonomy_G.report"))
  
  if (!file.exists(taxonomy_file) || !file.exists(taxonomy_G_file)) {
    warning("taxonomy file missing, skip sample:", sample_name)
    next
  }
  
  tax_df <- read.delim(taxonomy_file, header = TRUE, sep = "\t", stringsAsFactors = FALSE)
  tax_G_df <- read.delim(taxonomy_G_file, header = TRUE, sep = "\t", stringsAsFactors = FALSE)
  
  sample_dir <- file.path(data_path, sample_name)
  if (!dir.exists(sample_dir)) {
    warning("10X data directory not exist, skip sample:", sample_name)
    next
  }
  
  expr_mat <- tryCatch(Read10X(data.dir = sample_dir), error = function(e) {
    warning("Failed to read 10X data, skip sample:", sample_name)
    return(NULL)
  })
  
  if (is.null(expr_mat) || ncol(expr_mat) == 0) {
    warning("Expression matrix is empty, skip sample:", sample_name)
    next
  }
  
  gene_num_raw <- nrow(expr_mat)
  cell_num_raw <- ncol(expr_mat)
  median_nonzero_raw <- median(Matrix::colSums(expr_mat != 0))
  
  if (!"fraction_total_reads" %in% colnames(tax_G_df)) {
    warning("fraction_total_reads column missing, skip sample:", sample_name)
    next
  }
  
  filtered_tax_G_df <- tax_G_df[tax_G_df$fraction_total_reads > 0.2, ]
  if (nrow(filtered_tax_G_df) == 0) {
    warning("No cells meet criteria after filtering, skip sample:", sample_name)
    next
  }
  
  keep_cells_tmp <- intersect(colnames(expr_mat), filtered_tax_G_df$barcode)
  if (length(keep_cells_tmp) > 0) {
    expr_mat_tmp <- expr_mat[, keep_cells_tmp, drop = FALSE]
    gene_num_tmp <- nrow(expr_mat_tmp)
    cell_num_tmp <- ncol(expr_mat_tmp)
    median_nonzero_tmp <- median(Matrix::colSums(expr_mat_tmp != 0))
  } else {
    warning("No overlapping cells with expression matrix after filtering, skip sample:", sample_name)
    next
  }
  
  if (!"barcode" %in% colnames(filtered_tax_G_df)) {
    warning("barcode column missing, skip sample:", sample_name)
    next
  }
  
  keep_cells <- intersect(colnames(expr_mat), filtered_tax_G_df$barcode)
  if (length(keep_cells) == 0) {
    warning("No overlapping cells, skip sample:", sample_name)
    next
  }
  
  expr_mat_filtered <- expr_mat[, keep_cells, drop = FALSE]
  
  nonzero_counts <- Matrix::colSums(expr_mat_filtered != 0)
  top_cells <- names(sort(nonzero_counts, decreasing = TRUE))[1:min(20000, length(nonzero_counts))]
  expr_mat_top <- expr_mat_filtered[, top_cells, drop = FALSE]
  
  if (ncol(expr_mat_top) == 0) {
    warning("No cells left after filtering, skip sample:", sample_name)
    next
  }
  
  sample <- CreateSeuratObject(counts = expr_mat_top, min.cells = 10, min.features = 10)
  
  sample@meta.data$gene_number <- Matrix::colSums(GetAssayData(sample, slot = "counts") != 0)
  
  tax_G_match <- tax_G_df[match(colnames(sample), tax_G_df$barcode), ]
  tax_match <- tax_df[match(colnames(sample), tax_df$barcode), ]
  
  sample@meta.data$genus <- tax_G_match$name
  sample@meta.data$species <- tax_match$name
  sample@meta.data$sample <- sample_name
  sample@meta.data$site <- substr(sample@meta.data$sample, 1, 2)
  
  expr_counts <- GetAssayData(sample, slot = "counts")
  gene_num <- nrow(expr_counts)
  cell_num <- ncol(expr_counts)
  median_nonzero <- median(Matrix::colSums(expr_counts != 0))
  
  seurat_list[[sample_name]] <- sample
}

for (sample_name in names(seurat_list)) {
  sample_obj <- seurat_list[[sample_name]]
  old_barcodes <- colnames(sample_obj)
  new_barcodes <- paste0(sample_name, "_", old_barcodes)
  colnames(sample_obj) <- new_barcodes
  rownames(sample_obj@meta.data) <- new_barcodes
  seurat_list[[sample_name]] <- sample_obj
}

all_genes <- unique(unlist(lapply(seurat_list, function(x) rownames(x))))

for (sample_name in names(seurat_list)) {
  sample_obj <- seurat_list[[sample_name]]
  missing_genes <- setdiff(all_genes, rownames(sample_obj))
  
  if (length(missing_genes) > 0) {
    zero_mat <- matrix(0, nrow = length(missing_genes), ncol = ncol(sample_obj))
    rownames(zero_mat) <- missing_genes
    colnames(zero_mat) <- colnames(sample_obj)
    expr_mat_full <- rbind(GetAssayData(sample_obj, slot = "counts"), zero_mat)
    sample_obj <- CreateSeuratObject(counts = expr_mat_full, meta.data = sample_obj@meta.data)
  }
  
  seurat_list[[sample_name]] <- sample_obj
}

if (length(seurat_list) > 1) {
  combined_seurat_object <- Reduce(function(x, y) merge(x, y), seurat_list)
} else if (length(seurat_list) == 1) {
  combined_seurat_object <- seurat_list[[1]]
} else {
  stop("No valid samples loaded")
}

combined_seurat_object <- subset(
  combined_seurat_object,
  subset = nCount_RNA > 0 & is.finite(nCount_RNA) & species != "Homo sapiens"
)
saveRDS(combined_seurat_object, file.path(data_path,"marine_SeuratObject.rds"))

combined_seurat_object <- SCTransform(
  combined_seurat_object, 
  vars.to.regress = NULL, 
  verbose = FALSE,
  return.only.var.genes = FALSE, 
  variable.features.n = 2000
)
saveRDS(combined_seurat_object, file.path(data_path,"marine_SeuratObject_SCTransform.rds"))

combined_seurat_object <- RunPCA(
  combined_seurat_object, 
  features = VariableFeatures(combined_seurat_object)
)

pdf("ElbowPlot_all.pdf")
ElbowPlot(combined_seurat_object, ndims = 50, reduction = "pca")
dev.off()

combined_seurat_object <- combined_seurat_object %>%
  RunUMAP(reduction = "pca", dims = 1:20) %>%
  FindNeighbors(reduction = "pca", dims = 1:20) %>%
  FindClusters(resolution = 0.1)

# --- Save metadata & Seurat object ---
write.csv(combined_seurat_object@meta.data, file.path(data_path,"marine_meta_data.csv"), row.names=TRUE)
saveRDS(combined_seurat_object, file.path(data_path,"marine_SeuratObject_dim20_res10.rds"))

# --- 1. All-samples UMAP by cluster ---
p_cluster <- DimPlot(combined_seurat_object, reduction="umap", group.by="seurat_clusters", label=T, pt.size=0.4) +
  ggtitle("Marine UMAP - by cluster") + theme(plot.title = element_text(hjust=0.5))

# --- 2. All-samples UMAP by sample ---
p_sample <- DimPlot(combined_seurat_object, reduction="umap", group.by="sample", pt.size=0.4) +
  ggtitle("Marine UMAP - by sample") + theme(plot.title = element_text(hjust=0.5))

# --- 3. All-samples UMAP by site ---
p_site <- DimPlot(marine, reduction="umap", group.by="site", pt.size=0.4) +
  ggtitle("Marine UMAP - by sampling site") + theme(plot.title = element_text(hjust=0.5))

# --- 4. Species topN + Others + Unknown (based on species column) ---
topSpeciesN <- 30
meta <- marine@meta.data
species_totals <- meta %>%
  group_by(species) %>%
  summarise(n_cells = n(), .groups = "drop") %>%
  arrange(desc(n_cells))

top_species <- species_totals$species[species_totals$species != "Unknown"] %>% head(topSpeciesN)

marine$species_plot <- ifelse(marine$species %in% top_species, marine$species,
                              ifelse(marine$species == "Unknown", "Unknown", "Others"))

species_levels <- c(top_species, "Others", "Unknown")
marine$species_plot <- factor(marine$species_plot, levels = unique(species_levels))

# --- 5. Top N species coloring ---
n_colors_needed <- length(levels(marine$species_plot)) - 2  # 除去 Others 和 Unknown

# 主调色板（Top species）
if(n_colors_needed <= 12){
  pal_main <- brewer.pal(max(n_colors_needed, 3), "Paired")[1:n_colors_needed]
} else if(n_colors_needed <= 20){
  pal_main <- colorRampPalette(brewer.pal(12, "Set3"))(n_colors_needed)
} else {
  pal_main <- viridis(n_colors_needed, option = "turbo")
}

# 设置 Others 和 Unknown 颜色
pal <- c(pal_main,
         "Others" = "grey75",     # 中灰
         "Unknown" = "grey45")    # 深灰，区分Others

names(pal) <- levels(marine$species_plot)

# --- 7. Species UMAP ---
p_species <- DimPlot(marine, reduction="umap", group.by="species_plot", pt.size=0.4) +
  scale_colour_manual(values = pal) +
  ggtitle(paste0("Species UMAP (Top ", topSpeciesN," + Others)")) +
  theme(legend.position = "bottom", legend.title = element_text(size = 12), legend.text = element_text(size = 10), legend.key.size = unit(0.4, "lines"), legend.spacing.y = unit(0.1, "lines"), plot.title = element_text(hjust=0.5))+
  guides(color = guide_legend(override.aes = list(size = 4), ncol = 3))  # 图例分成3列，可调

# --- 10. Save individual plots ---
ggsave(file.path(data_path,"UMAP_by_cluster.pdf"), p_cluster, width=7, height=6, dpi=300)
ggsave(file.path(data_path,"UMAP_by_sample.pdf"), p_sample, width=7, height=6, dpi=300)
ggsave(file.path(data_path,"UMAP_by_site.pdf"), p_site, width=7, height=6, dpi=300)
ggsave(file.path(data_path,"UMAP_by_group.pdf"), p_group, width=7, height=6, dpi=300)
ggsave(file.path(data_path,paste0("UMAP_by_species_top", topSpeciesN,".pdf")), p_species, width=8, height=10, dpi=300)



### Find markers
combined_seurat_object <- readRDS(file="marine_SeuratObject_dim20_res10.rds")
### Find Markers for each cluster
combined_seurat_object <- PrepSCTFindMarkers(combined_seurat_object)

markers <- FindAllMarkers(
  combined_seurat_object,
  assay = "SCT",
  only.pos = TRUE,
  min.pct = 0.05,
  logfc.threshold = 0.2
)

markers <- markers %>%
  arrange(cluster, desc(avg_log2FC))

write.table(
  markers,
  file = "all_clusters_DEGs.tsv",
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)

