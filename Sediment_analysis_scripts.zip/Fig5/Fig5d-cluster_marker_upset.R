library(UpSetR)
library(dplyr)

# =========================
# 1. 读数据
# =========================
df <- read.table(file="manual_cluster_markers.tsv",header = T,sep = "\t")

df <- df %>%
  select(cluster, gene) %>%
  distinct()

gene_list <- split(df$gene, df$cluster)

# 按 marker 数排序（推荐）
cluster_sizes <- sort(sapply(gene_list, length), decreasing = TRUE)
gene_list <- gene_list[names(cluster_sizes)]

all_genes <- unique(df$gene)

binary_df <- data.frame(gene = all_genes)

for (cl in names(gene_list)) {
  binary_df[[cl]] <- as.integer(all_genes %in% gene_list[[cl]])
}

binary_df$gene <- NULL

pdf("Fig5d-UpSet_cluster_intersection.pdf", width = 9, height = 5)

UpSetR::upset(
  binary_df,
  sets = colnames(binary_df),
  order.by = "freq",
  keep.order = TRUE,
  main.bar.color = "black",
  sets.bar.color = "black"
)

dev.off()




library(ggplot2)
library(dplyr)

df <- read.table(file="manual_cluster_markers.tsv",header = T,sep = "\t")

df <- df %>%
  select(cluster, gene) %>%
  distinct()

# =========================
# 1. 统计每个cluster marker gene数
# =========================
cluster_size_df <- df %>%
  group_by(cluster) %>%
  summarise(n_genes = n()) %>%
  arrange(desc(n_genes))   # ⭐关键：排序

# =========================
# 2. 固定cluster顺序（非常重要）
# =========================
cluster_size_df$cluster <- factor(cluster_size_df$cluster,
                                  levels = cluster_size_df$cluster)

# =========================
# 3. color palette
# =========================
cluster_palette <- c(
  "0"="#9ECAE1",
  "1"="#D2B48C",
  "2"="#7570b3",
  "3"="#D3D3D3",
  "4"="#D0DDCC",
  "5"="#FFE4E1",
  "6"="#4192C6",
  "7"="#FFFF99",
  "8"="#e6ab02",
  "9"="#D8BFD8",
  "10"="#fb9a99",
  "11"="#b2df8a",
  "12"="#B07AA1",
  "13"="#A9A9A9",
  "14"="#59A14F"
)

# =========================
# 4. plot
# =========================
pdf("Fig5d-cluster_size_barplot_sorted.pdf", width = 6, height = 4)

ggplot(cluster_size_df, aes(x = cluster, y = n_genes, fill = cluster)) +
  geom_bar(stat = "identity") +
  scale_fill_manual(values = cluster_palette) +
  theme_classic() +
  theme(
    axis.title = element_text(size = 12),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "none"
  ) +
  labs(x = "Cluster", y = "Number of marker genes")

dev.off()