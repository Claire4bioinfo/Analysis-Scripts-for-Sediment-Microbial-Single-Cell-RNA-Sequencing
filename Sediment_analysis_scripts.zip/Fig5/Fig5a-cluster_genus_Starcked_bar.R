library(dplyr)
library(ggplot2)
library(scales)

# ===== 1. 准备数据 =====
meta <- combined_seurat_object@meta.data %>%
  as.data.frame() %>%
  select(manual_cluster, genus) %>%
  filter(!is.na(genus))

# 计算每个 genus 总数，用于 top30
genus_total <- meta %>%
  group_by(genus) %>%
  summarise(total_count = n(), .groups = "drop") %>%
  arrange(desc(total_count))

top_genus <- genus_total$genus[1:30]  # top30 genus

# 标记 Other
meta <- meta %>%
  mutate(genus2 = ifelse(genus %in% top_genus, genus, "Other"))

# ===== 2. 计算每个 cluster genus 比例 =====
cluster_genus_ratio <- meta %>%
  group_by(manual_cluster, genus2) %>%
  summarise(cell_count = n(), .groups = "drop") %>%
  group_by(manual_cluster) %>%
  mutate(ratio = cell_count / sum(cell_count)) %>%
  ungroup()

# ===== 3. 设置 factor 顺序 =====
cluster_genus_ratio$manual_cluster <- factor(cluster_genus_ratio$manual_cluster,
                                              levels = sort(unique(cluster_genus_ratio$manual_cluster)))

# 这里把 Other 放在第一个 level → 堆叠柱底部
genus_order <- c("Other", top_genus)
cluster_genus_ratio$genus2 <- factor(cluster_genus_ratio$genus2, levels = genus_order)

# ===== 4. 设置颜色 =====
set.seed(123)

base_colors <- c(
  RColorBrewer::brewer.pal(8, "Paired"),
  RColorBrewer::brewer.pal(8, "Set3"),
  RColorBrewer::brewer.pal(8, "Dark2"),
  RColorBrewer::brewer.pal(8, "Accent")
)

# 现在共有 32 种颜色
# 只取前30种
base_colors <- base_colors[1:30]

# ===== 替换最后6种颜色为亮色（自己选择或用ColorBrewer其他palette） =====
bright_colors <- c("#B15928","#66C2A5","#B113B3","#E7298A","#FFFF33","#999999")  # 6种鲜明颜色
base_colors[25:30] <- bright_colors
#base_colors[(length(base_colors)):length(base_colors)] <- bright_colors
# ===== 生成颜色向量，Other 白色 =====
genus_colors <- c(setNames(base_colors, top_genus),Other = "white")

# ===== 5. 绘制水平堆叠柱状图 =====
p <- ggplot(cluster_genus_ratio, aes(x = manual_cluster, y = ratio, fill = genus2)) +
  geom_bar(stat = "identity", width = 0.7) +   # 去掉边框
  scale_y_continuous(labels = percent_format(accuracy = 1), expand = c(0, 0)) +  # 去掉两端空白
  scale_fill_manual(values = genus_colors) +
  coord_flip() +  # 横向堆叠柱状图
  theme_bw() +
  theme(
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    axis.title = element_text(size = 12),
    panel.border = element_rect(color = "black", fill = NA, size = 1),
    legend.title = element_text(size = 12),
    legend.text = element_text(size = 10)
  ) +
  labs(
    x = "Cluster",
    y = "Genus Ratio",
    fill = "Genus",
    title = "Genus Composition per Cluster (Top30 + Other at bottom)"
  )

# ===== 6. 保存图 =====
#ggsave("Fig5a-Cluster_Genus_Top30_StackedBar.png", p, width = 10, height = 10, dpi = 300)
ggsave("Fig5a-Cluster_Genus_Top30_StackedBar.pdf", p, width = 10, height = 10)