#!/usr/bin/env Rscript
# ---------------------------------------------------------------------------
# within_taxon_reclustering.R
#
# Re-cluster the cells of one taxon on KEGG orthologue counts and describe the
# transcriptional states that result: marker orthologues, KEGG pathway activity,
# enrichment of the markers in each pathway, and the reproducibility of the
# partition.
#
#
# Usage
#   Rscript within_taxon_reclustering.R "Pseudoalteromonas tunicata" 0.2
#   Rscript within_taxon_reclustering.R "Shewanella" 0.2
#   Rscript within_taxon_reclustering.R "Methylomonas rapida,Methylogaea oryzae" 0.05
#
# Inputs (edit the paths below)
#   SEURAT_RDS   Seurat object with an RNA assay of raw counts and, in the
#                metadata, the columns named in SPECIES_COL and GENUS_COL.
#   ANNOTATION   table with one row per gene and the columns
#                  gene          gene identifier, as in rownames(counts)
#                  KO            KEGG orthologue, e.g. K01897, NA if none
#                  KEGG_pathway  comma-separated map/ko identifiers, may be NA
#   PATHWAY_NAMES  optional two-column table: map identifier, pathway name.
#
# ---------------------------------------------------------------------------

suppressPackageStartupMessages({
  library(Seurat); library(Matrix); library(data.table); library(ggplot2); library(mclust)
})

## ---- configuration --------------------------------------------------------
SEURAT_RDS    <- "data/atlas.rds"
ANNOTATION    <- "data/gene_annotation.tsv"
PATHWAY_NAMES <- "data/kegg_pathway_names.tsv"   # set to NA to use map identifiers
OUT_DIR       <- "results"
SPECIES_COL   <- "species"
GENUS_COL     <- "genus"

MIN_CELLS_PER_KO <- 5     # keep orthologues detected in at least this many cells
N_PCS            <- 10    # principal components used for UMAP and clustering
MIN_PATHWAY_KOS  <- 5     # keep pathways with at least this many detected orthologues
SEED             <- 42

## ---- command line ---------------------------------------------------------
args  <- commandArgs(trailingOnly = TRUE)
taxon <- if (length(args) >= 1) args[1] else stop("give a taxon name")
res   <- if (length(args) >= 2) as.numeric(args[2]) else 0.2
label <- gsub("[^A-Za-z0-9]+", "_", taxon)
dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)
set.seed(SEED)

## ---- 1. the cells of the taxon --------------------------------------------
obj <- readRDS(SEURAT_RDS)
cnt <- LayerData(obj, assay = "RNA", layer = "counts")
md  <- as.data.table(obj@meta.data, keep.rownames = "cell")
want  <- trimws(strsplit(taxon, ",")[[1]])
cells <- md[get(SPECIES_COL) %in% want | get(GENUS_COL) %in% want, cell]
if (!length(cells)) stop("no cells found for: ", taxon)
message(sprintf("%s: %d cells", taxon, length(cells)))

## ---- 2. genes to KEGG orthologues -----------------------------------------
ann <- fread(ANNOTATION)[!is.na(KO) & KO != ""]
ann <- ann[gene %in% rownames(cnt)]
X   <- cnt[ann$gene, cells, drop = FALSE]
S   <- sparse.model.matrix(~ 0 + factor(ann$KO))
colnames(S) <- levels(factor(ann$KO))
K   <- Matrix::t(S) %*% X                                   # orthologues x cells
K   <- K[Matrix::rowSums(K > 0) >= MIN_CELLS_PER_KO, , drop = FALSE]
K   <- K[, Matrix::colSums(K) > 0, drop = FALSE]
message(sprintf("  %d orthologues x %d cells after filtering", nrow(K), ncol(K)))

## ---- 3. normalise, embed, cluster -----------------------------------------
s <- CreateSeuratObject(counts = K, assay = "KO", project = label)
s <- SCTransform(s, assay = "KO", vst.flavor = "v2", verbose = FALSE,
                 variable.features.n = nrow(K))
npc <- min(N_PCS, ncol(K) - 1, nrow(s[["SCT"]]) - 1)
s <- RunPCA(s, npcs = npc, verbose = FALSE)
s <- RunUMAP(s, dims = 1:npc, verbose = FALSE)
s <- FindNeighbors(s, dims = 1:npc, verbose = FALSE)
s <- FindClusters(s, resolution = res, verbose = FALSE)
message(sprintf("  %d transcriptional states at resolution %s", nlevels(Idents(s)), res))

## ---- 4. marker orthologues of each state ----------------------------------
mk <- as.data.table(FindAllMarkers(s, assay = "SCT", only.pos = TRUE,
                                   min.pct = 0.05, logfc.threshold = 0.25, verbose = FALSE))
if (nrow(mk)) setnames(mk, "gene", "KO")
mk <- mk[p_val_adj < 0.05]
message(sprintf("  %d marker orthologues at adjusted P < 0.05", nrow(mk)))

## ---- 5. pathway activity and marker enrichment ----------------------------
counts <- LayerData(s, assay = "KO", layer = "counts")
depth  <- pmax(Matrix::colSums(counts), 1)
share  <- Matrix::t(Matrix::t(counts) / depth)              # each cell's share per orthologue
state  <- Idents(s)

pw <- unique(ann[!is.na(KEGG_pathway) & KEGG_pathway != "", .(KO, KEGG_pathway)], by = "KO")
pw <- pw[, .(map = unlist(strsplit(KEGG_pathway, ","))), by = KO][grepl("^ko", map)]
pw <- pw[KO %in% rownames(counts)]
if (!is.na(PATHWAY_NAMES) && file.exists(PATHWAY_NAMES)) {
  nmz <- fread(PATHWAY_NAMES, header = FALSE, col.names = c("map", "name"))
  nmz[, map := sub("^map", "ko", map)]
  pw  <- merge(pw, nmz, by = "map")[, .(KO, name)]
} else pw[, name := map]
sets <- split(pw$KO, pw$name)
sets <- sets[lengths(sets) >= MIN_PATHWAY_KOS]

activity <- rbindlist(lapply(names(sets), function(p) {
  v <- Matrix::colSums(share[sets[[p]], , drop = FALSE])
  data.table(pathway = p, state = levels(state), mean_share = as.numeric(tapply(v, state, mean)))
}))
activity[, z := (mean_share - mean(mean_share)) / max(sd(mean_share), 1e-9), by = pathway]

universe <- rownames(counts)
enrich <- rbindlist(lapply(levels(state), function(k) {
  hit <- unique(mk[cluster == k, KO]); if (length(hit) < 2) return(NULL)
  rbindlist(lapply(names(sets), function(p) {
    inset <- intersect(sets[[p]], universe); x <- length(intersect(hit, inset))
    if (x < 2) return(NULL)
    data.table(state = k, pathway = p, markers_in_pathway = x, markers = length(hit),
               pathway_size = length(inset),
               p = phyper(x - 1, length(inset), length(universe) - length(inset), length(hit),
                          lower.tail = FALSE))
  }))
}))
if (nrow(enrich)) enrich[, q := p.adjust(p, "BH")]