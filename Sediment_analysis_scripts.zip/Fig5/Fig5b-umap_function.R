library(Seurat)
library(dplyr)
library(ggplot2)
library(stringr)
library(harmony)
library(tidyverse)
library(tidyr)
library(ggrepel)
library(glmGamPoi)
library(RColorBrewer)
library(ggsci)
library(viridis)
library(Matrix)
library(pracma)
library(randomcoloR)
library(scico)

setwd("C:/Users/bioin/Downloads/Marine_revision/Marine_new_matrix/Matrix")
data_path <- "C:/Users/bioin/Downloads/Marine_revision/Marine_new_matrix/Matrix"

###manually merge cluster
combined_seurat_object <- readRDS("marine_SeuratObject_dim20_res10_manual.rds")

# 2️⃣ 选取 15 种颜色
cluster_colors <- c("#9ECAE1","#D2B48C","#7570b3","#D3D3D3","#D0DDCC",
                    "#FFE4E1","#4192C6","#FFFF99","#e6ab02","#D8BFD8",
                    "#fb9a99","#b2df8a","#B07AA1","#59A14F","#A9A9A9")

###画功能聚类图谱
cluster_COG_map <- c(
  "0"="Cell division and chromosome partitioning",
  "1"="Inorganic ion transport and metabolism",
  "2"="Membrane protein biogenesis",
  "3"="Transcription and cofactor metabolism",
  "4"="Protein folding and stress response",
  "5"="Phosphate transport and metabolism",
  "6"="Energy metabolism",
  "7"="Aromatic amino acid biosynthesis",
  "8"="Redox metabolism and amino acid biosynthesis",
  "9"="Carbohydrate metabolism",
  "10"="Purine biosynthesis",
  "11"="Ion homeostasis and cellular adaptation",
  "12"="DNA replication and chromosome maintenance",
  "13"="Unknown",
  "14"="Signal transduction and membrane functions"
)
COG_df <- data.frame(
  COG = cluster_COG_map[as.character(combined_seurat_object$manual_cluster)],
  row.names = colnames(combined_seurat_object)
)

combined_seurat_object <- AddMetaData(combined_seurat_object, COG_df)

combined_seurat_object$COG <- factor(combined_seurat_object$COG,
                     levels = c("Cell division and chromosome partitioning",
                                "Inorganic ion transport and metabolism",
                                "Membrane protein biogenesis",
                                "Transcription and cofactor metabolism",
                                "Protein folding and stress response",
                                "Phosphate transport and metabolism",
                                "Energy metabolism",
                                "Aromatic amino acid biosynthesis",
                                "Redox metabolism and amino acid biosynthesis",
                                "Carbohydrate metabolism",
                                "Purine biosynthesis",
                                "Ion homeostasis and cellular adaptation",
                                "DNA replication and chromosome maintenance",
                                "Unknown",
                                "Signal transduction and membrane functions"))
library(RColorBrewer)

cog_colors <- c(
  "Cell division and chromosome partitioning"="#9ECAE1",
  "Inorganic ion transport and metabolism"="#D2B48C",
  "Membrane protein biogenesis"="#7570b3",
  "Transcription and cofactor metabolism"="#D3D3D3",
  "Protein folding and stress response"="#D0DDCC",
  "Phosphate transport and metabolism"="#FFE4E1",
  "Energy metabolism"="#4192C6",
  "Aromatic amino acid biosynthesis"="#FFFF99",
  "Redox metabolism and amino acid biosynthesis"="#e6ab02",
  "Carbohydrate metabolism"="#D8BFD8",
  "Purine biosynthesis"="#fb9a99",
  "Ion homeostasis and cellular adaptation"="#b2df8a",
  "DNA replication and chromosome maintenance"="#B07AA1",
  "Unknown"="#A9A9A9",
  "Signal transduction and membrane functions"="#59A14F"
)

p <- DimPlot(combined_seurat_object,
        reduction = "umap",
        group.by = "COG",
        cols = cog_colors,
        label = FALSE,
        repel = TRUE,
        pt.size = 0.1) +
  ggtitle("UMAP colored by function")

ggsave("Fig5b-umap_function.png", p, width = 13, height = 8, dpi = 300)
ggsave("Fig5b-umap_function.pdf", p, width = 13, height = 8)
