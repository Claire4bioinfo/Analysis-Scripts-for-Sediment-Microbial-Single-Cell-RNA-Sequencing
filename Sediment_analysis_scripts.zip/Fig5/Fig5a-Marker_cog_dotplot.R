library(dplyr)
library(Seurat)
library(ggplot2)
library(grid)  # 用于 unit()

setwd("C:/Users/bioin/Downloads/Marine_revision/Marine_new_matrix/Matrix")
data_path <- "C:/Users/bioin/Downloads/Marine_revision/Marine_new_matrix/Matrix"
# ===== 1. 设置 Seurat identity =====
combined_seurat_object <- readRDS(file="marine_SeuratObject_dim20_res10_manual.rds")
combined_seurat_object$manual_cluster <- factor(combined_seurat_object$manual_cluster, levels = 0:14)
Idents(combined_seurat_object) <- "manual_cluster"

# ===== 2. 读取 DEG + 注释 =====
deg <- read.delim("manual_cluster_markers.tsv", sep = "\t", header = TRUE)
anno <- read.delim("Sediment_eggnog_manual.emapper.annotations", sep = "\t", header = TRUE, comment.char = "#")

anno$query <- gsub("_", "-", anno$query)
anno_small <- anno %>% select(query, Preferred_name, COG_category)
deg_anno <- deg %>% left_join(anno_small, by = c("gene" = "query"))

# ===== 3. 每个 cluster 选前3个有COG的marker =====
topN <- deg_anno %>%
  filter(p_val_adj < 0.05,
         !is.na(COG_category) & COG_category != "",
         !is.na(Preferred_name) & Preferred_name != "" & Preferred_name != "-") %>%  # 只保留有 Preferred_name 的
  group_by(cluster) %>%
  slice_max(order_by = abs(avg_log2FC), n = 3, with_ties = FALSE) %>%
  ungroup() %>%
  mutate(marker_label = paste0(gene, "|", Preferred_name, "|", COG_category)) %>%  # marker_label 新格式
  distinct(marker_label, .keep_all = TRUE)

topN <- topN %>%
  mutate(group_label = paste0(Preferred_name, "|", COG_category))

# 提取表达矩阵（用 data slot）
expr_mat <- GetAssayData(combined_seurat_object, slot = "data")

# gene → group 映射
gene2group <- topN$group_label
names(gene2group) <- topN$gene

# 只保留存在的基因
gene2group <- gene2group[names(gene2group) %in% rownames(expr_mat)]

# 分组聚合（求平均）
group_expr <- sapply(unique(gene2group), function(g){
  genes <- names(gene2group)[gene2group == g]
  Matrix::colMeans(expr_mat[genes, , drop = FALSE])
})

# 转置成 gene x cell
group_expr <- t(group_expr)

new_seurat <- CreateSeuratObject(counts = group_expr)

# 保留原 metadata
new_seurat@meta.data <- combined_seurat_object@meta.data

Idents(new_seurat) <- "manual_cluster"


p <- DotPlot(
  new_seurat,
  features = rownames(new_seurat),
  group.by = "manual_cluster",
  dot.scale = 7
) +
  scale_x_discrete(labels = rownames(new_seurat)) +
  scale_color_gradient2(low = "blue", mid = "white", high = "red", midpoint = 0) +
  scale_size_continuous(range = c(1.5, 6)) +  # 最大最小点尺寸适中
  theme_bw() +
  theme(
    axis.text.x = element_text(angle = 90, hjust = 1, size = 8),  # 横坐标字体调大
    axis.text.y = element_text(size = 10),                         # 纵坐标字体调大
    axis.title = element_text(size = 12),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "black", fill = NA, size = 1), # 加边框
    plot.title = element_text(hjust = 0.5, size = 14),
    axis.ticks.x = element_blank(),
    axis.ticks.length = unit(0, "pt")
  ) +
  labs(
    title = "Top 3 Marker Genes per Cluster (with gene name)",
    x = "Preferred Name | COG Category",
    y = "Cluster",
    color = "avg.exp",
    size = "pct.exp"
  )

# ===== 6. 保存 =====
ggsave("DotPlot_top3_marker_geneName_final.png", p, width = 8, height = 6, dpi = 300)
ggsave("DotPlot_top3_marker_geneName_final.pdf", p, width = 8, height = 6, dpi = 300)


write.table(deg_anno, file = "manual_markers_anno.tsv", sep = "\t",quote = FALSE, row.names = FALSE)
