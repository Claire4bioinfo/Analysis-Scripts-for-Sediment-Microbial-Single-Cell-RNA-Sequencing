library(dplyr)
library(ggplot2)
library(reshape2)

# =========================
# 1. 读数据
# =========================
df <- read.table(file="manual_cluster_markers.tsv",header = T,sep = "\t")

df <- df %>%
  select(cluster, gene) %>%
  distinct()

gene_list <- split(df$gene, df$cluster)

# cluster排序 + 命名
clusters <- sort(unique(df$cluster))
cluster_names <- paste0("Cluster_", clusters)

names(gene_list) <- cluster_names

# =========================
# 2. overlap coefficient matrix
# =========================
ov_mat <- matrix(0, length(cluster_names), length(cluster_names))
rownames(ov_mat) <- cluster_names
colnames(ov_mat) <- cluster_names

for (i in cluster_names) {
  for (j in cluster_names) {
    
    gi <- gene_list[[i]]
    gj <- gene_list[[j]]
    
    inter <- length(intersect(gi, gj))
    
    ov_mat[i, j] <- inter / min(length(gi), length(gj))
  }
}

# =========================
# 3. reshape
# =========================
ov_df <- melt(ov_mat)
colnames(ov_df) <- c("Cluster1", "Cluster2", "value")

# 保证顺序
ov_df$Cluster1 <- factor(ov_df$Cluster1, levels = cluster_names)
ov_df$Cluster2 <- factor(ov_df$Cluster2, levels = cluster_names)

# =========================
# 4. 画图（论文版）
# =========================
pdf("Fig5c-cluster_overlap_heatmap.pdf", width = 6.5, height = 6)

ggplot(ov_df, aes(Cluster1, Cluster2, fill = value)) +
  
  geom_tile(color = "white") +
  
  # 数值标注（核心）
  geom_text(aes(label = sprintf("%.2f", value)), size = 3) +
  
  scale_fill_gradient(low = "white", high = "#2c7bb6") 

dev.off()
