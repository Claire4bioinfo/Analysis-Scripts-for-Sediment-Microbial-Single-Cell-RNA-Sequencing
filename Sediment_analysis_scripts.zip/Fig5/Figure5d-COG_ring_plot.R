library(dplyr)
library(ggplot2)

# =========================
# 1. 读取数据
# =========================
df <- read.csv("manual_cluster_markers_anno.csv")

df <- df %>%
  select(gene, COG_category) %>%
  filter(!is.na(COG_category)) %>%
  distinct()

# =========================
# 2. 清洗 COG category
# =========================
df$COG_category <- gsub("-", "", df$COG_category)
df$COG_category <- toupper(trimws(df$COG_category))

df <- df %>%
  filter(COG_category != "", COG_category != "NA")

# =========================
# 3. Top10 COG
# =========================
top10_cog <- df %>%
  count(COG_category, sort = TRUE) %>%
  slice_head(n = 10) %>%
  pull(COG_category)

# =========================
# 4. 分组
# =========================
df$COG_group <- ifelse(df$COG_category %in% top10_cog,
                       df$COG_category,
                       "Others")

# =========================
# 5. 统计比例
# =========================
plot_df <- df %>%
  count(COG_group) %>%
  mutate(percent = n / sum(n) * 100)

# 顺序
order_levels <- c(sort(top10_cog), "Others")
plot_df$COG_group <- factor(plot_df$COG_group, levels = order_levels)

# =========================
# 6. 颜色映射
# =========================
top10_colors <- c(
  "#1f77b4", "#ff7f0e", "#2ca02c", "#d62728",
  "#9467bd", "#8c564b", "#FF9999", "#FFFF99",
  "#bcbd22", "#17becf"
)

names(top10_colors) <- sort(top10_cog)

fill_colors <- c(top10_colors, Others = "#D3D3D3")

# =========================
# 7. ring plot
# =========================
pdf("Fig5d-COG_ring_plot.pdf", width = 6, height = 6)

ggplot(plot_df, aes(x = 2, y = percent, fill = COG_group)) +
  geom_bar(stat = "identity", width = 1, color = "white") +
  coord_polar(theta = "y") +
  xlim(0.5, 2.5) +
  
  scale_fill_manual(values = fill_colors) +
  
  theme_void() +
  theme(
    legend.title = element_blank(),
    legend.text = element_text(size = 10)
  ) +
  
  geom_text(aes(label = paste0(round(percent, 1), "%")),
            position = position_stack(vjust = 0.5),
            size = 3)

dev.off()