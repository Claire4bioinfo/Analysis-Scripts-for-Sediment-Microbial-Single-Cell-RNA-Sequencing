library(dplyr)
library(tidyr)
library(pheatmap)
library(RColorBrewer)
library(grid)

setwd("C:/Users/bioin/Downloads/Marine_revision/Marine_new_matrix/Matrix/")
combined_seurat_object <- readRDS("marine_SeuratObject_dim20_res10_manual.rds")
# === 参数 ===
topN <- 60
outdir <- "speciesAbund_plots"
dir.create(outdir, showWarnings = FALSE)
sample_order <- c("ZJB","ZJ5","SGB","SG5","HYB","HY5","ZSB","ZS4")

# === 统计物种 abundance（cell 数） ===
meta <- combined_seurat_object@meta.data %>%
  as.data.frame() %>%
  mutate(cell = rownames(.)) %>%
  filter(!is.na(species))

# 按 sample & species 计数
species_counts <- meta %>%
  group_by(sample, species) %>%
  summarise(cell_number = n(), .groups="drop")

# 计算相对丰度
species_abundance <- species_counts %>%
  group_by(sample) %>%
  mutate(relative_abundance = cell_number / sum(cell_number)) %>%
  ungroup()

# === 筛选前60物种 ===
top60_species <- species_abundance %>%
  group_by(species) %>%
  summarise(total_cells = sum(cell_number), .groups = "drop") %>%
  arrange(desc(total_cells)) %>%
  slice_head(n = topN) %>%
  pull(species)

species_abundance_top60 <- species_abundance %>%
  filter(species %in% top60_species)

# === 构建物种 × 样本矩阵 ===
heat_df <- species_abundance_top60 %>%
  select(sample, species, relative_abundance) %>%
  pivot_wider(names_from = sample, values_from = relative_abundance, values_fill = 0)

# 保存行名并删除 species 列
row_names <- heat_df$species
heat_df <- heat_df %>% select(-species)

# 保持样本顺序
heat_df <- heat_df[, sample_order, drop = FALSE]

# 转矩阵并设置行名
mat <- as.matrix(heat_df)
rownames(mat) <- row_names

# === 自定义颜色：低丰度蓝 -> 中丰度绿 -> 高丰度黄 ===
my_colors <- colorRampPalette(c("#086082", "#2a9cbe", "#d4dd3c", "#ffff33"))(100)

pdf(file = file.path(outdir, "species_heatmap_top60.pdf"),
    width = 8,
    height = nrow(mat) * 0.25,
    useDingbats = FALSE)

p <- pheatmap(mat,
              cluster_rows = TRUE,
              cluster_cols = FALSE,
              scale = "row",
              fontsize_row = 8,
              fontsize_col = 10,
              show_rownames = TRUE,
              color = my_colors,
              border_color = "white",
              cellheight = 10,     # PDF里稍微调小一点更紧凑
              cellwidth = 20,
              main = "Top 60 Most Abundant Species Across Samples"
)

# =========================
# 右侧添加斜体物种名
# =========================
species_names <- rownames(mat)
n_rows <- nrow(mat)

y_positions <- seq(1 - 1/(2*n_rows), 1/(2*n_rows), length.out = n_rows)

for (i in seq_along(species_names)) {
  grid.text(
    label = species_names[i],
    x = unit(1, "npc") + unit(2, "mm"),
    y = unit(y_positions[i], "npc"),
    just = "left",
    gp = gpar(fontsize = 8, fontface = "italic")
  )
}

dev.off()