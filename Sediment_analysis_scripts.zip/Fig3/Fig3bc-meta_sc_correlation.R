library(tidyverse)
library(readr)
library(patchwork)

setwd("C:/Users/bioin/Downloads/soil_sc/data_zlx/Marine_final/meta_sm_correlation")

### 1 读入数据
meta <- read_tsv("meta_species.tsv") |> as.data.frame()
sc   <- read_tsv("sm_species.tsv")   |> as.data.frame()

rownames(meta) <- meta$Species
meta$Species <- NULL

rownames(sc) <- sc$Species
sc$Species <- NULL

###2 保留共有物种
common_species <- intersect(rownames(meta), rownames(sc))

meta <- meta[common_species, ]
sc   <- sc[common_species, ]

###3 保留共有样本
common_samples <- c("HY5","ZSB")

meta <- meta[, common_samples]
sc   <- sc[, common_samples]

meta <- as.matrix(meta)
sc   <- as.matrix(sc)
###4 选top abundance species
mean_abundance <- rowMeans(meta)

top_species <- names(sort(mean_abundance, decreasing=TRUE))[1:12]

meta_top <- meta[top_species, ]
sc_top   <- sc[top_species, ]

###5 计算相关性
cors <- sapply(common_samples, function(s){
  
  cor(meta_top[,s],
      sc_top[,s],
      method="spearman")
  
})

cors

###5 画Scatter plot
plots <- lapply(common_samples, function(s){
  
  df <- data.frame(
    meta = meta_top[,s],
    sc   = sc_top[,s]
  )
  
  cor_test <- cor.test(df$meta, df$sc, method="spearman")
  
  ggplot(df, aes(sc, meta)) +
    
    geom_point(size=2, alpha=0.7, color="blue") +
    
    geom_smooth(
      method="lm",
      color="black",
      fill="grey80",   # 置信区间颜色
      se=TRUE
    ) +
    
    theme_bw(base_size=14) +
    
    labs(
      title = s,
      x = "smRNA-seq species abundance",
      y = "Metagenomics species abundance"
    ) +
    
    annotate(
      "text",
      x = min(df$sc),
      y = max(df$meta),
      hjust = 0,
      label = paste0(
        "Spearman R = ", round(cor_test$estimate,2),
        "\np = ", signif(cor_test$p.value,2)
      )
    )
  
})
plots

final_plot <- wrap_plots(plots, ncol=3)

final_plot

ggsave(
  "meta_vs_smRNA_species_correlation.pdf",
  final_plot,
  width=12,
  height=8
)