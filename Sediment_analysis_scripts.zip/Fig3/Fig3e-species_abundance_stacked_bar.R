library(Seurat)
library(dplyr)
library(tidyr)
library(ggplot2)
library(RColorBrewer)
library(scales)
library(grid)

setwd("C:/Users/bioin/Downloads/Marine_revision/Marine_new_matrix/Matrix/")
combined_seurat_object <- readRDS("marine_SeuratObject_dim20_res10_manual.rds")
# === 参数 ===
topN_each_sample <- 3   # 每个样本选前3个物种
outdir <- "speciesAbund_plots"
dir.create(outdir, showWarnings = FALSE)

# === 统计物种 abundance（cell 数） ===
meta <- combined_seurat_object@meta.data %>%
  as.data.frame() %>%
  mutate(cell = rownames(.)) %>%
  filter(!is.na(species))

# 按 sample & species 计数
species_counts <- meta %>%
  group_by(sample, species) %>%
  summarise(cell_number = n(), .groups="drop")

# 计算相对丰度
species_abundance <- species_counts %>%
  group_by(sample) %>%
  mutate(relative_abundance = cell_number / sum(cell_number)) %>%
  ungroup()

# === 选每个样本前 topN_each_sample 物种 ===
top_species_each_sample <- species_abundance %>%
  group_by(sample) %>%
  slice_max(order_by = cell_number, n = topN_each_sample, with_ties = FALSE) %>%
  ungroup() %>%
  pull(species) %>%
  unique()   # 并集

# === 标注 Others ===
species_abundance <- species_abundance %>%
  mutate(species_plot = ifelse(species %in% top_species_each_sample, species, "Others"))

# === 聚合 Others ===
species_abundance_plot <- species_abundance %>%
  group_by(sample, species_plot) %>%
  summarise(cell_number = sum(cell_number), .groups="drop") %>%
  group_by(sample) %>%
  mutate(relative_abundance = cell_number / sum(cell_number)) %>%
  ungroup()

# === sample 顺序 ===
sample_order <- c("ZJB","ZJ5","SGB","SG5","HYB","HY5","ZSB","ZS4")
species_abundance_plot$sample <- factor(species_abundance_plot$sample, levels = sample_order)

# === 设置堆叠 factor levels: Others 底部 + 其余按丰度排序 ===
global_order <- species_abundance_plot %>%
  group_by(species_plot) %>%
  summarise(total_abundance = sum(relative_abundance), .groups="drop") %>%
  arrange(desc(total_abundance)) %>%
  pull(species_plot)

top_species_order <- setdiff(global_order, "Others")
species_levels_stack <- c("Others", rev(top_species_order))
species_abundance_plot <- species_abundance_plot %>%
  mutate(species_plot_ordered = factor(species_plot, levels = species_levels_stack))

# === 调色板 ===
pal <- colorRampPalette(brewer.pal(min(12, length(species_levels_stack)), "Paired"))(length(species_levels_stack))
pal <- rev(pal)
pal_named <- setNames(pal, species_levels_stack)
pal_named["Others"] <- "grey75"

# 图例顺序
legend_levels <- c(top_species_order, "Others")

write.csv(
  species_abundance_plot,
  file = "species_abundance_0429.csv",
  row.names = FALSE
)
# === 绘制堆叠柱状图 ===
p_bar <- ggplot(species_abundance_plot,
                aes(x = sample, y = relative_abundance, fill = species_plot_ordered)) +
  geom_bar(stat="identity", width=0.8, color="black", size=0.1) +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  scale_fill_manual(values = pal_named, breaks = legend_levels) +
  labs(x = "", y = "Relative abundance", fill = "Species") +
  theme_bw() +
  theme(
    axis.text.x = element_text(angle=45, hjust=1),
    panel.grid = element_blank(),
    legend.position = "right",
    legend.title.align = 0.5,
    legend.key.size = unit(0.3, "cm"),
    legend.text = element_text(size = 8),
    legend.direction = "horizontal"
  ) +
  guides(fill = guide_legend(ncol=2, title.position = "top"))

# === 保存图 ===
ggsave(filename = file.path(outdir, "Fig3e-species_barplot_top3.pdf"),
       plot = p_bar,
       width = 12,
       height = 8,
       device = "pdf",
       useDingbats = FALSE)
