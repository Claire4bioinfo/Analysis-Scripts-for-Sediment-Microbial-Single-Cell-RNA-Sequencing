library(Seurat)
library(dplyr)
library(tidyr)
library(ggplot2)
library(RColorBrewer)
library(scales)
library(grid)

setwd("C:/Users/bioin/Downloads/Marine_revision/Marine_new_matrix/Matrix")
combined_seurat_object <- readRDS("marine_SeuratObject_dim20_res10_manual.rds")
# === 参数 ===
topN_each_sample <- 3   # 每个样本选前3个物种
outdir <- "speciesAbund_plots"
dir.create(outdir, showWarnings = FALSE)

# === 统计物种 abundance（cell 数） ===
meta <- combined_seurat_object@meta.data %>%
  as.data.frame() %>%
  mutate(cell = rownames(.)) %>%
  filter(!is.na(genus))

# 按 sample & genus 计数
genus_counts <- meta %>%
  group_by(sample, genus) %>%
  summarise(cell_number = n(), .groups="drop")

# 计算相对丰度
genus_abundance <- genus_counts %>%
  group_by(sample) %>%
  mutate(relative_abundance = cell_number / sum(cell_number)) %>%
  ungroup()

# === 选每个样本前 topN_each_sample 物种 ===
top_genus_each_sample <- genus_abundance %>%
  group_by(sample) %>%
  slice_max(order_by = cell_number, n = topN_each_sample, with_ties = FALSE) %>%
  ungroup() %>%
  pull(genus) %>%
  unique()   # 并集

# === 标注 Others ===
genus_abundance <- genus_abundance %>%
  mutate(genus_plot = ifelse(genus %in% top_genus_each_sample, genus, "Others"))

# === 聚合 Others ===
genus_abundance_plot <- genus_abundance %>%
  group_by(sample, genus_plot) %>%
  summarise(cell_number = sum(cell_number), .groups="drop") %>%
  group_by(sample) %>%
  mutate(relative_abundance = cell_number / sum(cell_number)) %>%
  ungroup()

# === sample 顺序 ===
sample_order <- c("ZJB","ZJ5","SGB","SG5","HYB","HY5","ZSB","ZS4")
genus_abundance_plot$sample <- factor(genus_abundance_plot$sample, levels = sample_order)

# === 设置堆叠 factor levels: Others 底部 + 其余按丰度排序 ===
global_order <- genus_abundance_plot %>%
  group_by(genus_plot) %>%
  summarise(total_abundance = sum(relative_abundance), .groups="drop") %>%
  arrange(desc(total_abundance)) %>%
  pull(genus_plot)

top_genus_order <- setdiff(global_order, "Others")
genus_levels_stack <- c("Others", rev(top_genus_order))
genus_abundance_plot <- genus_abundance_plot %>%
  mutate(genus_plot_ordered = factor(genus_plot, levels = genus_levels_stack))

# === 调色板 ===
pal <- colorRampPalette(brewer.pal(min(12, length(genus_levels_stack)), "Paired"))(length(genus_levels_stack))
pal <- rev(pal)
pal_named <- setNames(pal, genus_levels_stack)
pal_named["Others"] <- "grey75"

# 图例顺序
legend_levels <- c(top_genus_order, "Others")

# === 绘制堆叠柱状图 ===
p_bar <- ggplot(genus_abundance_plot,
                aes(x = sample, y = relative_abundance, fill = genus_plot_ordered)) +
  geom_bar(stat="identity", width=0.8, color="black", size=0.1) +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  scale_fill_manual(values = pal_named, breaks = legend_levels) +
  labs(x = "", y = "Relative abundance", fill = "Genus") +
  theme_bw() +
  theme(
    axis.text.x = element_text(angle=45, hjust=1),
    panel.grid = element_blank(),
    legend.position = "bottom",
    legend.title.align = 0.5,
    legend.key.size = unit(0.3, "cm"),
    legend.text = element_text(size = 8),
    legend.direction = "horizontal"
  ) +
  guides(fill = guide_legend(ncol=4, title.position = "top"))

# === 保存图 ===
ggsave(filename = file.path(outdir, "Fig3d-genus_barplot_top3_each_sample_OthersBottom.pdf"),
       plot = p_bar,
       width = 6,
       height = 9,
       device = "pdf",
       useDingbats = FALSE)
