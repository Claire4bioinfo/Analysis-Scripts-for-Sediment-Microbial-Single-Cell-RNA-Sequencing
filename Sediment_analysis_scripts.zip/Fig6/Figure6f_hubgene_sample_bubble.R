# =========================
# 0. 加载包
# =========================
library(dplyr)
library(tidyr)
library(ggplot2)
library(readr)
library(stringr)
library(tibble)
library(tidyverse)

# =========================
# 1. 读取数据
# =========================
setwd("C:/Users/bioin/Downloads/Marine_revision/Marine_new_matrix/Matrix")
fraction_df <- read_csv("module_gene_fraction_by_sample.csv")
expr_df     <- read_csv("module_gene_mean_expr_by_sample.csv")
annot_df    <- read_csv("combined_module_genes_anno.csv")

# =========================
# 2. gene设为行名
# =========================
fraction_df <- as.data.frame(fraction_df)
rownames(fraction_df) <- fraction_df$gene
fraction_df$gene <- NULL

expr_df <- as.data.frame(expr_df)
rownames(expr_df) <- expr_df$gene
expr_df$gene <- NULL

# =========================
# 3. kME筛选 + COG过滤
# =========================
annot_df <- annot_df %>%
  filter(COG_ID != "-")

top_genes_df <- annot_df %>%
  arrange(module, desc(kME)) %>%
  group_by(module) %>%
  slice_head(n = 5)

module_genes <- top_genes_df$gene_name

cat("Selected genes:", length(module_genes), "\n")

# =========================
# 4. 过滤 expression matrix
# =========================
fraction_df <- fraction_df[rownames(fraction_df) %in% module_genes, ]
expr_df     <- expr_df[rownames(expr_df) %in% module_genes, ]

if (nrow(fraction_df) == 0) stop("No genes passed filtering")

# =========================
# 5. 0-1 scaling（按gene）
# =========================
scale01 <- function(x){
  if (max(x) == min(x)) return(rep(0, length(x)))
  (x - min(x)) / (max(x) - min(x))
}

scaled_fraction_df <- t(apply(fraction_df, 1, scale01)) %>% as.data.frame()
scaled_expr_df     <- t(apply(expr_df, 1, scale01)) %>% as.data.frame()

# =========================
# 6. clustering（gene顺序）
# =========================
clust_df <- na.omit(scaled_fraction_df)

dist_mat <- dist(clust_df)
hc <- hclust(dist_mat, method = "average")

gene_order <- rownames(clust_df)[hc$order]

# =========================
# 7. 转长表
# =========================
fraction_melt <- scaled_fraction_df %>%
  rownames_to_column("gene") %>%
  pivot_longer(-gene, names_to = "sample", values_to = "fraction")

expr_melt <- scaled_expr_df %>%
  rownames_to_column("gene") %>%
  pivot_longer(-gene, names_to = "sample", values_to = "expr")

merged <- left_join(fraction_melt, expr_melt, by = c("gene", "sample"))

# =========================
# 8. 顺序控制
# =========================
sample_order <- c("ZJB", "ZJ5","SGB", "SG5","HYB","HY5", "ZSB", "ZS4")

merged <- merged %>%
  mutate(
    sample = factor(sample, levels = sample_order),
    gene = factor(gene, levels = gene_order)
  ) %>%
  arrange(gene, sample)

# clip
merged <- merged %>%
  mutate(
    fraction = pmin(pmax(fraction, 0), 1),
    expr = pmin(pmax(expr, 0), 1)
  )

# =========================
# 9. x轴位置（制造间距）
# =========================
sample_position_map <- c(ZJB = 0.8, ZJ5 = 0.9, SGB = 1.0, SG5 = 1.1, HYB = 1.2, HY5 = 1.3, ZSB = 1.4, ZS4 = 1.5)

merged <- merged %>%
  mutate(x = sample_position_map[as.character(sample)])

# =========================
# 10. 绘图
# =========================
p <- ggplot(merged, aes(x = x, y = gene)) +
  geom_point(aes(size = fraction, color = expr)) +
  
  scale_size(range = c(2, 10)) +
  scale_color_gradient(low = "#fee0d2", high = "#67000d") +
  
  scale_x_continuous(
    breaks = c(0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4, 1.5),
    labels = sample_order,
  ) +
  
  labs(x = "sample", y = "Module Gene") +
  
  theme_classic() +
  theme(
    axis.title = element_text(size = 20),
    axis.text.x = element_text(size = 15),
    axis.text.y = element_text(size = 14, face = "italic"),
    legend.position = "right",
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1)
  )
# =========================
# 11. 保存
# =========================
ggsave("Figure6f_module_gene_bubble_sample.pdf", p, width = 10, height = 15)

