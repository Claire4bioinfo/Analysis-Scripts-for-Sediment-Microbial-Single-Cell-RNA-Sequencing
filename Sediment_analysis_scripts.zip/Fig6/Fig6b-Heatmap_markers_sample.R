library(dplyr)
library(Seurat)
library(ggplot2)
library(grid)  # 用于 unit()

setwd("C:/Users/bioin/Downloads/Marine_revision/Marine_new_matrix/Matrix")
data_path <- "C:/Users/bioin/Downloads/Marine_revision/Marine_new_matrix/Matrix"
# ===== 1. 设置 Seurat identity =====
combined_seurat_object <- readRDS(file="marine_SeuratObject_dim20_res10_manual.rds")
combined_seurat_object$manual_cluster <- factor(combined_seurat_object$manual_cluster, levels = 0:14)
Idents(combined_seurat_object) <- "manual_cluster"

# ===== 2. 读取 DEG + 注释 =====
deg <- read.delim("manual_cluster_markers.tsv", sep = "\t", header = TRUE)
anno <- read.delim("Sediment_eggnog_manual.emapper.annotations", sep = "\t", header = TRUE, comment.char = "#")

anno$query <- gsub("_", "-", anno$query)
anno_small <- anno %>% select(query, Preferred_name, COG_category)
deg_anno <- deg %>% left_join(anno_small, by = c("gene" = "query"))

# ===== 3. 每个 cluster 选前3个有COG的marker =====
topN <- deg_anno %>%
  filter(p_val_adj < 0.05,
         !is.na(COG_category) & COG_category != "",
         !is.na(Preferred_name) & Preferred_name != "" & Preferred_name != "-") %>%  # 只保留有 Preferred_name 的
  group_by(cluster) %>%
  slice_max(order_by = abs(avg_log2FC), n = 3, with_ties = FALSE) %>%
  ungroup() %>%
  mutate(marker_label = paste0(gene, "|", Preferred_name, "|", COG_category)) %>%  # marker_label 新格式
  distinct(marker_label, .keep_all = TRUE)

topN <- topN %>%
  mutate(group_label = paste0(Preferred_name, "|", COG_category))

# 提取表达矩阵（用 data slot）
expr_mat <- GetAssayData(combined_seurat_object, slot = "data")

# gene → group 映射
gene2group <- topN$group_label
names(gene2group) <- topN$gene

# 只保留存在的基因
gene2group <- gene2group[names(gene2group) %in% rownames(expr_mat)]

# 分组聚合（求平均）
group_expr <- sapply(unique(gene2group), function(g){
  genes <- names(gene2group)[gene2group == g]
  Matrix::colMeans(expr_mat[genes, , drop = FALSE])
})

# 转置成 gene x cell
group_expr <- t(group_expr)

new_seurat <- CreateSeuratObject(counts = group_expr)

# 保留原 metadata
new_seurat@meta.data <- combined_seurat_object@meta.data

Idents(new_seurat) <- "manual_cluster"


dp <- DotPlot(
  new_seurat,
  features = rownames(new_seurat),
  group.by = "sample"
)

df <- dp$data

#2
library(dplyr)
library(tidyr)

mat <- df %>%
  select(features.plot, id, avg.exp.scaled) %>%  # 用 scaled 更像 DotPlot 颜色
  pivot_wider(names_from = id, values_from = avg.exp.scaled)

# 转成 matrix
mat <- as.data.frame(mat)
rownames(mat) <- mat$features.plot
mat$features.plot <- NULL
mat <- as.matrix(mat)

#3
# sample 顺序
sample_order <- c("ZJB","ZJ5","SGB","SG5","HYB","HY5","ZSB","ZS4")
mat <- mat[, sample_order]

# gene 顺序
cog <- sub(".*-", "", rownames(mat))

gene_order <- order(cog, -apply(mat, 1, var))
mat <- mat[gene_order, ]

#4
library(ggplot2)

df2 <- as.data.frame(mat)
df2$gene <- factor(rownames(df2), levels = rownames(mat))  # ⭐关键

df_long <- df2 %>%
  pivot_longer(-gene, names_to = "sample", values_to = "expr")
df_long$sample <- factor(df_long$sample, levels = sample_order)

p <- ggplot(df_long, aes(x = sample, y = gene, fill = expr)) +
  geom_tile() +
  scale_fill_gradient2(low = "blue", mid = "white", high = "red", midpoint = 0) +
  theme_bw() +
  theme(
    axis.text.x = element_text(angle = 90, hjust = 1, size = 8),
    axis.text.y = element_text(size = 8),
    panel.grid = element_blank(),
    panel.border = element_rect(color = "black", fill = NA, size = 1)
  ) +
  labs(
    title = "Marker Gene Expression Heatmap",
    x = "Sample",
    y = "Preferred Name | COG",
    fill = "avg.exp"
  )

# ===== 6. 保存 =====
ggsave("Fig6b-Heatmap_markers_sample.png", p, width = 5, height = 6, dpi = 300)
ggsave("Fig6b-Heatmap_markers_sample.pdf", p, width = 5, height = 6, dpi = 300)
