library(dplyr)
library(ggplot2)

# =========================================================
# 0. 基础信息
# =========================================================
setwd("C:/Users/bioin/Downloads/Marine_revision/Marine_new_matrix/Matrix")
data_path <- "C:/Users/bioin/Downloads/Marine_revision/Marine_new_matrix/Matrix"

###manually merge cluster
combined_seurat_object <- readRDS("marine_SeuratObject_dim20_res10_manual.rds") 

expr <- GetAssayData(
  combined_seurat_object,
  assay = "SCT",
  slot = "data"
)

species <- combined_seurat_object$species
sample_order <- c(
  "ZJB",
  "ZJ5",
  "SGB",
  "SG5",
  "HYB",
  "HY5",
  "ZSB",
  "ZS4"
)

sample <- factor(
  combined_seurat_object$sample,
  levels = sample_order
)

top_species_use <- top_species[1:20]

# =========================================================
# 1. 构建 Fig6A 数据
# =========================================================

fig6A_df <- data.frame()

for (sp in top_species_use) {
  
  cells_sp <- names(species[species == sp])
  
  for (sm in unique(sample)) {
    
    cells_sm <- names(sample[sample == sm])
    
    cells <- intersect(cells_sp, cells_sm)
    
    if (length(cells) < 5) next
    
    sub <- expr[, cells, drop = FALSE]
    
    mean_expr <- Matrix::rowMeans(sub)
    frac_expr <- Matrix::rowSums(sub > 0) / ncol(sub)
    
    df <- data.frame(
      species = sp,
      sample = sm,
      gene = rownames(sub),
      mean_expr = mean_expr,
      fraction = frac_expr
    )
    
    fig6A_df <- rbind(fig6A_df, df)
  }
}

# =========================================================
# 2. 聚合（species-level）
# =========================================================

fig6A_sum <- fig6A_df %>%
  
  group_by(species, sample) %>%
  
  summarise(
    mean_expr = mean(mean_expr),
    fraction = mean(fraction),
    .groups = "drop"
  )

# =========================================================
# 3. 排序
# =========================================================

fig6A_sum$species <- factor(
  fig6A_sum$species,
  levels = top_species_use
)

fig6A_sum$sample <- factor(fig6A_sum$sample, levels = sample_order)

# =========================================================
# 4. plot
# =========================================================

p6a <- ggplot(fig6A_sum, aes(x = sample, y = species)) +
  
  geom_point(
    aes(
      size = fraction,
      color = mean_expr
    ),
    alpha = 0.85
  ) +
  
  scale_color_viridis_c(option = "C") +
  scale_size(range = c(1, 8)) +
  
  theme_bw() +
  
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    panel.grid = element_blank()
  ) +
  
  labs(
    x = "Sample",
    y = "Species",
    color = "Mean expression",
    size = "Fraction",
    title = "Species activity shifts across marine sediment samples"
  )

print(p6a)

ggsave("Fig6a_species_sample_activity_top20.pdf", p6a, width = 10, height = 6)