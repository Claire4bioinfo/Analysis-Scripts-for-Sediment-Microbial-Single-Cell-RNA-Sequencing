# ===============================================
# Author : Xiao Xiong
# Date   : 2026-04-10
# Project: Marine mscRNA-seq Analysis
# ===============================================

library(Seurat)
library(dplyr)
library(ggplot2)
library(harmony)
library(tidyverse)
library(tidyr)
library(ggrepel)
library(glmGamPoi)
library(RColorBrewer)
library(ggsci)
library(viridis)
library(Matrix)
library(ggrastr)
library(patchwork)
library(irlba)
library(hdWGCNA)
library(cowplot)
library(WGCNA)
library(ggradar)

# Set working directory
setwd("C:/Users/bioin/Downloads/Marine_revision/Marine_new_matrix/Matrix")

markers <- read.table(file="manual_cluster_markers.tsv", sep = "\t", header = T)
combined_seurat_object <- readRDS(file="marine_SeuratObject_dim20_res10_manual.rds")
# Extract normalized expression matrix and cluster identities
counts <- GetAssayData(combined_seurat_object, assay = "SCT", slot = "data")
clusters <- combined_seurat_object$manual_cluster

markers$gene <- gsub("_", "-", markers$gene)
genes <- unique(markers$gene)
genes <- genes[genes %in% rownames(counts)]

cluster_ids <- sort(unique(clusters))
cluster_names <- paste0("Cluster_", cluster_ids)

fraction_mat <- matrix(0, nrow = length(genes), ncol = length(cluster_ids),
                       dimnames = list(genes, cluster_names))
mean_mat <- matrix(0, nrow = length(genes), ncol = length(cluster_ids),
                   dimnames = list(genes, cluster_names))

# Calculate expression fraction and mean expression per cluster
for (cid in cluster_ids) {
  cluster_cells <- names(clusters[clusters == cid])
  sub_counts <- counts[genes, cluster_cells, drop = FALSE]
  
  fraction <- rowSums(sub_counts > 0) / length(cluster_cells)
  mean_expr <- rowMeans(sub_counts)
  
  fraction_mat[, paste0("Cluster_", cid)] <- fraction
  mean_mat[, paste0("Cluster_", cid)] <- mean_expr
}

write.csv(fraction_mat, "gene_fraction_by_cluster.csv", quote = FALSE)
write.csv(mean_mat, "gene_mean_expr_by_cluster.csv", quote = FALSE)

# Prepare Seurat object for hdWGCNA by selecting highly expressed genes
theme_set(theme_cowplot())
enableWGCNAThreads(nThreads = 16)
combined_seurat_object <- SetupForWGCNA(
  combined_seurat_object,
  gene_select = "fraction",
  fraction = 0.01,
  wgcna_name = "combined"
)
selected_genes <- GetWGCNAGenes(combined_seurat_object, wgcna_name = "combined")
cat("Number of selected genes:", length(selected_genes), "\n")

# Run PCA on the selected genes
combined_seurat_object <- RunPCA(combined_seurat_object)

# Construct metacells for each cluster and normalize their expression
combined_seurat_object$manual_cluster <- as.factor(combined_seurat_object$manual_cluster)
combined_seurat_object <- SetIdent(combined_seurat_object, value = "manual_cluster")
combined_seurat_object <- MetacellsByGroups(
  seurat_obj = combined_seurat_object,
  reduction = "pca",
  k = 25,
  max_shared = 10,
  group.by = "manual_cluster",
  ident.group = "manual_cluster"
)
combined_seurat_object <- NormalizeMetacells(combined_seurat_object)

# Keep only selected genes for WGCNA analysis
combined_seurat_object <- subset(
  combined_seurat_object,
  features = selected_genes
)

# Set expression matrix and test soft-thresholding powers
combined_seurat_object <- SetDatExpr(
  combined_seurat_object,
  assay = "SCT",
  layer = "data"
)
combined_seurat_object <- TestSoftPowers(
  combined_seurat_object,
  networkType = "signed" 
)

# Visualize and save soft power selection plots
plot_list <- PlotSoftPowers(combined_seurat_object)
combined_plot <- wrap_plots(plot_list, ncol = 2)
pdf("FigureS6a.pdf", width = 10, height = 9)
print(combined_plot)
dev.off()
power_table <- GetPowerTable(combined_seurat_object)
head(power_table)

# Construct WGCNA co-expression network and detect modules
combined_seurat_object <- ConstructNetwork(
  combined_seurat_object,
  tom_name = "combined_network",
  overwrite_tom = TRUE,
  minModuleSize = 30,
  mergeCutHeight = 0.25
)

# Load precomputed TOM matrix and assign gene names
tom_file <- "C:/Users/bioin/Downloads/Marine_revision/Marine_new_matrix/Matrix/TOM/combined_network_TOM.rda"

# Export gene dendrogram
pdf("FigureS6b.pdf", width = 6, height = 4, useDingbats = FALSE)
PlotDendrogram(combined_seurat_object, main = "Gene dendrogram")
dev.off()

# Compute module eigengenes, connectivity, and visualize relationships
combined_seurat_object <- ModuleEigengenes(combined_seurat_object)
combined_seurat_object <- ModuleConnectivity(combined_seurat_object)
PlotKMEs(combined_seurat_object, ncol = 3)

# Retrieve module information, remove grey module, and identify hub genes
modules <- GetModules(combined_seurat_object) %>% subset(module != "grey")
module_df <- GetHubGenes(combined_seurat_object, n_hubs = 1000)
write.csv(module_df, "combined_module_genes.csv", row.names = FALSE, quote = FALSE)

# Extract module gene expression and save expression matrices by sample
module_gene_df <- data.frame(
  gene = unlist(modules$gene),
  module = rep(modules$module, sapply(modules$gene, length))
)
module_genes <- module_gene_df[["gene"]]
expr_matrix <- GetAssayData(combined_seurat_object, assay = "SCT", slot = "data")
module_genes <- intersect(module_genes, rownames(expr_matrix))
module_gene_expr_matrix <- expr_matrix[module_genes, , drop = FALSE]

# Compute fraction and mean expression of module genes for each sample
samples <- combined_seurat_object$sample
sample_ids <- sort(unique(samples))
fraction_mat <- mean_mat <- matrix(0, nrow = length(module_genes), ncol = length(sample_ids), dimnames = list(module_genes, paste0(sample_ids)))
for (tid in sample_ids) {
  sample_cells <- names(samples[samples == tid])
  sub_counts <- module_gene_expr_matrix[, sample_cells, drop = FALSE]
  fraction_mat[, paste0(tid)] <- rowSums(sub_counts > 0) / length(sample_cells)
  mean_mat[, paste0(tid)] <- rowMeans(sub_counts)
}
write.csv(fraction_mat, "module_gene_fraction_by_sample.csv", quote = FALSE)
write.csv(mean_mat, "module_gene_mean_expr_by_sample.csv", quote = FALSE)

# Calculate module activity scores using UCell
combined_seurat_object <- ModuleExprScore(combined_seurat_object, n_genes = 50, method = "UCell")


pdf("Figure6b.pdf", width = 14, height = 10)
plot_list <- ModuleFeaturePlot(combined_seurat_object, features = "scores", order = "shuffle", ucell = TRUE)
plot_list <- lapply(plot_list, function(p) {p + geom_point(size = 0.01) + theme(plot.title = element_text(size = 30, face = "bold"))})
wrap_plots(plot_list, ncol = 3)
dev.off()

# Set sample factor levels and generate module radar plot
#combined_seurat_object$sample <- substr(combined_seurat_object$sample, 1, 2)
combined_seurat_object$sample <- as.factor(combined_seurat_object$sample)

combined_seurat_object$sample <- factor(combined_seurat_object$sample, levels = c("ZJB", "SGB", "HYB", "ZSB", "ZJ5", "SG5", "HY5", "ZS4"))
pdf("Figure6c.pdf", width = 12, height = 10)
ModuleRadarPlot(combined_seurat_object, group.by = "sample", axis.label.size = 5, grid.label.size = 0)
dev.off()

# Save the final Seurat object with hdWGCNA results
saveRDS(combined_seurat_object, file = "combined_seurat_object_hdWGCNA_sample.rds")
cat("hdWGCNA analysis completed. Results saved to combined_seurat_object_hdWGCNA.rds\n")